package com.example.vrturist  // ak máš iný package, nechaj ten svoj

