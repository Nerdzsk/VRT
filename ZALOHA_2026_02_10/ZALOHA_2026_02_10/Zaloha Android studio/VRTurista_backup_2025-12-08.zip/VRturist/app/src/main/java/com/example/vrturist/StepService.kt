package com.example.vrturist

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.google.firebase.database.FirebaseDatabase

class StepService : Service(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var stepSensor: Sensor? = null
    private var baseSteps: Float = -1f

    private val channelId = "step_service_channel"
    private val notificationId = 1

    override fun onCreate() {
        super.onCreate()

        // Notifikačný kanál pre foreground service
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "VR Turista krokomer",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("VR Turista")
            .setContentText("Počítam kroky…")
            .setSmallIcon(com.example.vrturist.R.mipmap.ic_launcher) // alebo iná tvoja ikona
            .setOngoing(true)
            .build()

        startForeground(notificationId, notification)

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)

        if (stepSensor != null) {
            sensorManager.registerListener(
                this,
                stepSensor,
                SensorManager.SENSOR_DELAY_NORMAL
            )
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        sensorManager.unregisterListener(this)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_STEP_COUNTER) {
            val total = event.values[0]
            if (baseSteps < 0f) {
                baseSteps = total
            }
            val current = (total - baseSteps).toInt()

            // zapíš aktuálne kroky do Firebase
            val db = FirebaseDatabase.getInstance().reference
            db.child("steps").setValue(current)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // nič
    }
}
