package com.example.vrturist

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.core.content.ContextCompat
import com.example.vrturist.ui.theme.VRTuristTheme
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class MainActivity : ComponentActivity() {

    private var stepsState = mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // spustenie foreground služby, ktorá počíta kroky na pozadí
        val serviceIntent = Intent(this, StepService::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)

        // voliteľné: čítanie aktuálnych krokov z Firebase a zobrazenie v UI
        val dbRef = Firebase.database.reference.child("steps")
        dbRef.addValueEventListener(
            object : com.google.firebase.database.ValueEventListener {
                override fun onDataChange(snapshot: com.google.firebase.database.DataSnapshot) {
                    val value = snapshot.getValue(Int::class.java) ?: 0
                    stepsState.value = value
                }

                override fun onCancelled(error: com.google.firebase.database.DatabaseError) {
                    // nič
                }
            }
        )

        setContent {
            VRTuristTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Greeting(
                        name = stepsState.value.toString(),
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Kroky: $name",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    VRTuristTheme {
        Greeting("Android")
    }
}
